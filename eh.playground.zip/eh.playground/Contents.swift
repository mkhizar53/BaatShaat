import UIKit



let array = [1, 2, 3, 4, 5]

let newArray = array.map{$0 * 2}

print(newArray)
